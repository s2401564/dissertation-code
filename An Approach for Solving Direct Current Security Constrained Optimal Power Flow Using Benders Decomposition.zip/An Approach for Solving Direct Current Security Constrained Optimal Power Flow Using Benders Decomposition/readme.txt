This folder contains three subfolders. 

The first one is "MatpowerData"， 
which was downloaded from the https://matpower.org/download/ website 
and contains datasets used for studying OPF problems. 

The second one is "DCSCOPF"， 
which consists of model files, data files, and execution files 
used for solving the DC SC OPF problem. 

The third one is "Benders Decomposition"， 
which contains model files, data files, 
and execution files used for solving the problems 
after Benders Decomposition processing.