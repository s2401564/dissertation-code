function mpc = case3_lavaei
%CASE9    Power flow data for 9 bus, 3 generator case.
%   Please see CASEFORMAT for details on the case file format.
%
%   Based on data from Joe H. Chow's book, p. 70.

%   MATPOWER
%   $Id: case9.m,v 1.11 2010/03/10 18:08:14 ray Exp $

%% MATPOWER Case Format : Version 2
mpc.version = '2';

%%-----  Power Flow Data  -----%%
%% system MVA base
mpc.baseMVA = 100;

%% bus data
%	bus_i	type	Pd	Qd	Gs	Bs	area	Vm	Va	baseKV	zone	Vmax	Vmin
mpc.bus = [
	1	3	110	0	0	0	1	0.8	0      345	1	1.2	0.8;
	2	2	110	0	0	0	1	0.8	-65.0  345	1	1.2	0.8;
	3	2	50	0	0	0	1	0.8	-115.0  345	1	1.2	0.8;
	
];

%% generator data
%	bus	Pg	Qg	Qmax	Qmin	Vg	mBase	status	Pmax	Pmin	Pc1	Pc2	Qc1min	Qc1max	Qc2min	Qc2max	ramp_agc	ramp_10	ramp_30	ramp_q	apf
mpc.gen = [
	1	272 	33 	100	-100	0.8	100	1	350	    0       0	0	0	0	0	0	0	0	0	0	0;
	2	138 	36 	100	-100	0.8	100	1	350	    0   	0	0	0	0	0	0	0	0	0	0	0;
	3	0   	111	200	-200	0.8	100	1	0    	0   	0	0	0	0	0	0	0	0	0	0	0;
];

%% branch data
%	fbus	tbus	r	x	b	rateA	rateB	rateC	ratio	angle	status	angmin	angmax
mpc.branch = [
	1	2	0.42	0.90 	0.30   	25000	25000	25000	0	0	1	-360	360;
	2	3	0.25	0.75	0.70 	25000	25000	25000	0	0	1	-360	360;
	1	3	0.55	0.90 	0.45	25000	25000	25000	0	0	1	-360	360;
	
];

%%-----  OPF Data  -----%%
%% area data
%	area	refbus
mpc.areas = [
	1	1;
];

%% generator cost data
%	1	startup	shutdown	n	x1	y1	...	xn	yn
%	2	startup	shutdown	n	c(n-1)	...	c0
mpc.gencost = [
	2	0	0	3	0	5	0;
	2	0	0	3	0	1	0;
    2	0	0	3	0	0	0;
];
